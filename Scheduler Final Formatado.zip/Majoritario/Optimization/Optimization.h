// Imports
#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <queue>
#include <sstream>
#include <tuple>
#include <string.h>

// Constants
#define DEFAULT_LENGHT 10

using namespace std;

// Variables - Gantt
typedef int matrixId[DEFAULT_LENGHT][DEFAULT_LENGHT];
typedef float matrixTime[DEFAULT_LENGHT][DEFAULT_LENGHT];

// Variables - defining new types of data
typedef tuple<int, int, int, int, int>
    demand; // productId, quantity, date (day, month, year)
typedef tuple<int, vector<int>, vector<int>>
    product; // productId, machineId, machineTime

class Optimization {
private:
  vector<vector<int>> matrix; // optimization return
  vector<demand> demandVector;
  vector<product> productVector;
  vector<int> machineIds;

public:
  Optimization();
  ~Optimization();
  vector<demand> obtain_demand_vector(const string);
  vector<product> obtain_product_vector(const string);
  static bool compare_vector_by_deadline(demand &, demand &);
  vector<demand> sort_vector_by_deadline(vector<demand>);
  vector<product> calculate_machine_total_times(vector<product>,
                                                vector<demand>);
  vector<vector<int>> generate_matrix(vector<product>);
  string generate_file(vector<vector<int>> matrix);
};