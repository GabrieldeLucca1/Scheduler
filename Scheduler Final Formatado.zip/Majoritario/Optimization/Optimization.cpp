#include "Optimization.h"

// Constructor
Optimization::Optimization() {}

// Destructor
Optimization::~Optimization() {}

/********************* obtain_demand_vector **************************
**********************************************************************
Operation: convert given file into vector of demands;
Input Parameters: name of the demand file;
Output: vector of demands;
*/

vector<demand> Optimization::obtain_demand_vector(const string filename)
{

  // file reading
  ifstream file(filename);

  if (file.is_open())
  {
    int idProduct, quantity, day, month, year, idDemand, productAmount, zero;
    string initialDate, initialTime, finalDate, finalTime, strday, strmonth, stryear, line;
 
    vector<demand> demandVector;

    // read until the file is over
    while (getline(file, line))
    {
      stringstream file(line);

      // storing read data in variables
      file >> idDemand;
      file >> initialDate;
      file >> initialTime;
      file >> finalDate;
      file >> finalTime;
      file >> productAmount;

      for (int i = 0; i < productAmount; i++)
      {
        file >> idProduct;
        file >> quantity;
      }
      file >> zero;

      // separates finalDate (deadline) in day, month, year
      strday = finalDate[0];
      strday += finalDate[1];
      day = stoi(strday);

      strmonth = finalDate[3];
      strmonth += finalDate[4];
      month = stoi(strmonth);

      stryear = finalDate[6];
      stryear += finalDate[7];
      stryear += finalDate[8];
      stryear += finalDate[9];
      year = stoi(stryear);

      // add variables to the vector
      demandVector.push_back(make_tuple(idProduct, quantity, day, month, year));

    /************ TESTE DE LEITURA ***************
      cout << "productAmount " << productAmount << endl;
      cout << "finalDate " << finalDate << endl;
      cout << "finalDate[1] " << finalDate[1] << endl;
      cout << "day " << day << endl;
      cout << "month " << month << endl;
      cout << "year " << year << endl;
      cout << "FIM DO TESTE DE DEMANDA" << endl;
    **********************************************/

    }

    // close vector
    file.close();
    this->demandVector = demandVector;

    return demandVector;
  }
  else {
    printf("\nInexistent archive!!\n");
    exit(EXIT_FAILURE);
  }
};

/********************* obtain_product_vector **************************
***********************************************************************
Operation: convert given file into vector of products;
Input Parameters: name of the product file;
Output: vector of products;
*/

vector<product> Optimization::obtain_product_vector(const string filename)
{

  // file reading
  ifstream file(filename);

  if (!file.is_open())
  {
    printf("\nInexistent file!!\n");
    exit(EXIT_FAILURE);
  }
  else
  {
    vector<product> productVector;

    // read until the file is over
    while (file.good())
    {
      int idProduct, machineAmount;
      string productName;
      vector<int> machines, times;

      // reads product id and amount of machines it uses
      file >> productName;
      file >> idProduct;
      file >> machineAmount;

      // reads the machines and its times
      for (int j = 0; j < machineAmount; j++)
      {
        int machine;
        int time;
        file >> machine;
        file >> time;
        bool found = false;

        // seraches the machine id in the machine id vector, if it finds a different one, adds it
        for (int i = 0; i < this->machineIds.size() && !found; i++)
        {
          if (machine == this->machineIds[i])
          {
            found = true;
          }
        }

        if (!found)
        {
          this->machineIds.push_back(machine);
        }
        machines.push_back(machine);
        times.push_back(time);
      }
      // save the varibles read in the vector
      productVector.push_back(make_tuple(idProduct, machines, times));
    }

    file.close();
    return productVector;
  }
}

/********************* compare_vector_by_deadline **************************
****************************************************************************
Operation: determine which demand has the further deadline;
Input Parameters: two demands from vector demand;
Output: boolean value where false means that the first demand has bigger date and true if they're equal or second one is bigger;
Status: used in the sort_vector_by_deadline method;
*/

bool Optimization::compare_vector_by_deadline(demand &demand1,
                                              demand &demand2)
{
  // comparing years
  if (get<4>(demand1) > get<4>(demand2))
  {
    return false;
  }
  else if (get<4>(demand1) < get<4>(demand2))
  {
    return true;

    // same year: comparing months
  }
  else
  {
    if (get<3>(demand1) > get<3>(demand2))
      return false;

    else if (get<3>(demand1) < get<3>(demand2))
    {
      return true;

      // same month: comparing days
    }
    else
    {
      if (get<2>(demand1) > get<2>(demand2))
        return false;
      else
      {
        return true;
      }
    }
  }
};

/********************* sort_vector_by_deadline **************************
*************************************************************************
Operation: sort vector in ascending order by deadline;
Input Parameters: demand vector;
Output: ordered demand vector (same content);
Status: uses the compare_vector_by_deadline method;
*/

vector<demand>
Optimization::sort_vector_by_deadline(vector<demand> demandVector)
{
  sort(demandVector.begin(), demandVector.end(), compare_vector_by_deadline);
  return demandVector;
}

/********************* calculate_machine_total_times
**************************
*************************************************************
Operation: multiply all the execution times (time that the product
          spends in each machine) by the order quantity;
Input Parameters: both product and demand vector;
Output: updated product vector;
*/

vector<product>
Optimization::calculate_machine_total_times(vector<product> productVector,
                                            vector<demand> demandVector)
{
  int sizeDemand = demandVector.size();
  int sizeProduct = productVector.size();

  vector<product> completedProductVector;

  // scanning the demand vector
  for (int i = 0; i < sizeDemand; i++)
  {

    // gets the products manufactured in the machine
    int productId = get<0>(demandVector[i]);
    vector<int> machineId;
    vector<int> machineTime;

    // scans product vector
    for (int j = 0; j < sizeProduct; j++)
    {
      // searches product id on table demand
      if (productId == get<0>(productVector[j]))
      {

        // defines machineId (obtained from productVector)
        machineId = get<1>(productVector[j]);

        // redefines machineTime ((productVector) * quantity (from demand))
        machineTime = get<2>(productVector[j]);

        int quantity = get<1>(demandVector[i]);
        
        for (int k = 0; k < machineId.size(); k++)
        {
          machineTime[k] = machineTime[k] * quantity;
        }

        // storage values to a new vector (completedProductVector)
        completedProductVector.push_back(
            make_tuple(productId, machineId, machineTime));
      }
    }
  }
  this->productVector = completedProductVector;
  return completedProductVector; // [(productId, [machineId], [machineTime])]
};

/********************* generate_matrix **************************
*****************************************************************
Operation: organize machines execution route by placing products by priority (deadline);
Input Parameters: product vector obtained in calculate_machine_total_time method;
Output: matrix with machines and its execution route (products and its entry and exit time);
*/

vector<vector<int>>
Optimization::generate_matrix(vector<product> completedProductVector)
{
  vector<int> productFinalTimes;
  vector<int> productIds;
  vector<int> machineTime;
  machineTime.resize(machineIds.size());
  machineTime.clear();

  // defines first column of the matrix as the machine ids and initializes its time in the machine time vector as 0
  for (int k = 0; k < this->machineIds.size(); k++)
  {
    vector<int> line;
    line.clear();
    line.push_back(this->machineIds[k]);
    matrix.push_back(line);
    machineTime[k] = 0;
  }

  for (int i = 0; i < completedProductVector.size(); i++)
  {
    int productId = get<0>(completedProductVector[i]);
    int product_index = productIds.size();
    bool found = false;
    int finalTime = 0;

    for (int j = 0; j < productIds.size() && !found; j++)
    {
      if (productId == productIds[j])
      {
        product_index = j;
        found = true;
      }
    }

    if (!found)
    {
      productIds.push_back(productId);
      productFinalTimes.push_back(0);
    }

    // defining the machine where product is going
    vector<int> product_machines = get<1>(completedProductVector[i]);
    vector<int> product_machinesTimes = get<2>(completedProductVector[i]);

    for (int j = 0; j < product_machines.size(); j++)
    {
      finalTime = productFinalTimes[product_index];
      int machine = product_machines[j];
      int time = product_machinesTimes[j];
      int machine_index = 0;
      found = false;

      for (int w = 0; w < machineIds.size(); w++)
      {
        if (machine == machineIds[w])
        {
          machine_index = w;
          found = true;
        }
      }

      // adds productId in the line of the machine it will use
      matrix[machine_index].push_back(productId);

      // adds product initial time a position after
      // verifies which one is bigger to define as product initial time: last time product left a machine or last time machine was used
      int initialTime = machineTime[machine_index] > finalTime ? machineTime[machine_index] : finalTime;
      matrix[machine_index].push_back(initialTime);

      // adds product final time in the next position
      // defines final time as the sum of initial time and time spent in the machine
      finalTime = initialTime + time;
      matrix[machine_index].push_back(finalTime);

      // defines last machine used time as machine final time
      machineTime[machine_index] = finalTime;

      // defines the last time product was on a machine as product final time
      productFinalTimes[product_index] = finalTime;
    }
  }

  /******* TESTE DE CORRETUDE DA MATRIZ*******
  cout << matrix.size() << endl;
  cout << matrix[0].size() << endl;
  for (int v = 0; v < matrix.size(); v++){
    for (int g = 0; g < matrix[v].size(); g++){
      cout << matrix[v][g] << " ";
    }
    cout << endl;
  }
  *******************************************/

  return matrix;
};

/********************* generate_file **************************
***************************************************************
Operation: convert obtained matrix into .csv file;
Input Parameters: machines execution route matrix;
Output: name of the file;
*/

string Optimization::generate_file(vector<vector<int>> matrix)
{

  // Open CSV archive in write mode
  ofstream file("result.csv");

  if (!file.is_open())
  {
    cout << "The file couldn't be created";
    exit(EXIT_FAILURE);
  }
  else
  {
    // Scans the matrix and set all the elements into the file separated by space
    for (int i = 0; i<matrix.size(); i++){
      for (int j = 0; j<matrix[i].size(); j++){
        file << matrix[i][j] << ' ';
        if (j == matrix[i].size()-1)
          file << -1;
      }
      file << endl;
    }
  }

  // Closes the file
  file.close();

  return "result.csv";
};