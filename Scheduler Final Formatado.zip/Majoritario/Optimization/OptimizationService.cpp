// Libraries import 
#include "Optimization.h"
#include "../Initializations/optimization_init.h"
#include <iostream>
#include <queue>
#include <tuple>

using namespace std;

int startOptimization() {
  
  // variables declaration
  vector<demand> demandVector, sortedVector;
  vector<product> productVector, finalVector;
  vector<vector<int>> finalMatrix;
  string resultFile;

  // creating object
  Optimization optimization_service;

  // reading the files given and turning them into vectors
    //  demand file
  demandVector = optimization_service.obtain_demand_vector("demands.csv");
    //  product file
  productVector = optimization_service.obtain_product_vector("products.csv");

  // sorting products by deadline
  sortedVector = optimization_service.sort_vector_by_deadline(demandVector);

  // calculating total amount of time that the products will stay on the machines (multiplying by quantity demanded) 
  finalVector = optimization_service.calculate_machine_total_times(
      productVector, sortedVector);

  // generating matrix where lines are machines and columns contain id products and its time of entry and exit
  finalMatrix = optimization_service.generate_matrix(finalVector);

  // turning obtained matrix into a .csv file
  resultFile = optimization_service.generate_file(finalMatrix);

  cout << "Data has been optimized! Check out result.csv file." << endl;
  cout << "Returning to main menu." << endl;

  return 0;
}
