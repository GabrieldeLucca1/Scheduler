#ifndef PROD_INIT_H
#define PROD_INIT_H

void startProducts();

#endif