#ifndef OPTIMIZATION_INIT_H
#define OPTIMIZATION_INIT_H

int startOptimization();

#endif