#ifndef DEMAND_INIT_H
#define DEMAND_INIT_H

void startDemands();

#endif