#ifndef MACHINE_INIT_H
#define MACHINE_INIT_H

void start_machine_register_test();

#endif