## Comando para gerar main_debug
g++ *.cpp Maquinas/*.cpp Produtos/*cpp Demanda/*.cpp Otimizacao/*.cpp -o main_debug

## Comando para execução
./main_debug

## OBSERVAÇÃO: abrir com terminal Ubuntu (WSL) 

## PROBLEM LOGS

## MUDANÇAS RECENTES 