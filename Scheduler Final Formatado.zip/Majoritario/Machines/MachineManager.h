#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>
#include "Machine.h"
using namespace std;

class Facade_Machine {
    private:
        vector <Machine> registeredMachines;
    
    public:
        Facade_Machine();
        ~Facade_Machine() {};
        Machine search_machine_by_id(int id);
        void start_machine_register();
        void delete_machine(int id);
        void update_production_line(int id, int *v);
        int returns_index(int id);
        void create_machine();
        void consult_machine();
        void storage_update();
        void vector_from_storage();
};