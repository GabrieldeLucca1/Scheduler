#include <iostream>
using namespace std;
using std::string;

#define MAX 5

class Machine {

    public:
        Machine(int _id = 0, int _capacity = 0, int *_productLine = 0);
        ~Machine();
        void modify_machine(bool modifier, int* data);
        Machine view_machine() const;
        void view_production_line() const;
        int get_identifier();
        int get_capacity() const;
        int *get_production_line() const;
        void set_capacity(int capacity);
        void set_production_line(int *data);        

    private:
        int id;
        int capacity;
        int *productLine;
};

