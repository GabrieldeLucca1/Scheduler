#include "Machine.h"

Machine::Machine(int _id, int _capacity, int *_productionLine) {
    
    id = _id;
    capacity = _capacity;
    productLine = new int [MAX];
    productLine = _productionLine;
}

Machine::~Machine() {
   
}

int Machine::get_identifier() {
    return this->id;
}

int Machine::get_capacity() const {
    return this->capacity;
}

int *Machine::get_production_line() const {
    return this->productLine;
}

void Machine::set_capacity(int _capacity) {
    capacity = _capacity;
}

void Machine::set_production_line(int *data) {
    this->productLine = data;
}

/******************** modify_machine **************************
*************************************************************
Operation: Method that through Boolean input defines change in production line or machine capacity;
Input Parameters: bool modifier, int* data;
Output: Change in machine capacity or your production line
*/
void Machine::modify_machine(bool modifier, int* data) {

// If the modifier has a value of 1, the function set_production_line() is called to define a new production line
    if (modifier) {
        set_production_line(data); 
    }
 // If the modifier has a value of 0, the function set_capacity() is called to define a new capacity
    else {
        set_capacity(*data);
        this->view_machine(); 
    }
}


/******************** view_machine **************************
*************************************************************
Operation: Visualization of machine elements;
Input: No input
Output: Machine; */
Machine Machine::view_machine() const{
    cout << "Machine id: " << this->id << endl;
    cout << "Machine capacity: " << this->capacity << endl;
    // cout << this->view_production_line() << endl;

    return *this;
}


/******************** view_production_line **************************
*************************************************************
Operation: Method for visualization of machine production line in the interface;
Input: No input
Output: No output  */
void Machine::view_production_line() const {
    cout << get_production_line()[0]; 
    for (int i = 1; i < MAX; i++) {
        cout << " ---> " << get_production_line()[i]; 
    }
    cout << endl;
}