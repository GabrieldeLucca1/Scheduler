#include "MachineManager.h"

Facade_Machine::Facade_Machine() { // Constructer
    vector_from_storage();
}

/******************** start_machine_register **************************
*************************************************************
Operation: Starts the interface so the user can register machines
Input: no inputs
Output: no outputs  */
void Facade_Machine::start_machine_register() {
    cout << "=======================Machines======================= " << endl;
    cout << "[R] Register a new machine" << endl;
    cout << "[V] View or update an existing machine information" << endl;
    cout << "[E] Quit service" << endl;
    cout << "> ";

    char selector;
    cin >> selector;
    selector = toupper(selector);

    if (selector == 'R') { // Register a new machine
            create_machine();
    }

    else { // View a existing machine information
        if (selector == 'V') {
            consult_machine();
        }

        else { // Return to main menu
            cout << "Machine service says goodbye" << endl;
            storage_update();
        }
    }
}


/******************** create_machine **************************
*************************************************************
Operation: Creates a machine when the user requests this service
Input: no inputs
Output: no outputs  */
void Facade_Machine::create_machine() {
	bool repeated = false;
    int _capacity, _id;
    char selector;
    int *_productionLine;
    cout << "Type the identifier (ID) of the machine to be registered: ";
    cin >> _id;

    int i = 0;
    while (i < registeredMachines.size() && !repeated) { // Makes sure the machine hasnt been registered
        if (_id == registeredMachines.at(i).get_identifier()){
            cout << "This ID is already registered" << endl;
            repeated = true;
            start_machine_register();
        }
        else {
            repeated = false;
        }
        i++;
    }

    if (!repeated) {
        cout << "Type the capacity of the machine to be registered: ";
        cin >> _capacity;

        Machine new_machine(_id,_capacity,_productionLine);
        registeredMachines.push_back(new_machine); // Stores the machine in the vector of registrations
        storage_update();

        cout << endl;
        cout << "Do you want to leave the machine manager?" << endl;
        cout << "[C] Continue managing machines" << endl;
        cout << "[R] Return to main menu" << endl;
        cin >> selector;
        selector = toupper(selector);
        cout << "selector: " << selector << endl;

        if(selector=='C'){ // Continue managing machines
            cout << "percebeu que era C" << endl;
            cout << endl;
            cout << endl;
            start_machine_register();
        }
        else { // Return to main menu
            cout << "Machine register says goodbye" << endl;
            storage_update();
        }
    }
}


/******************** consult_machine **************************
*************************************************************
Operation: When the user requests this service it allows to se informations of the machine, its production line, to delete it or just to leave machine registering
Input: no inputs
Output: no outputs  */
void Facade_Machine::consult_machine() {
    cout << endl;

    if (registeredMachines.size()>0) { // Checks if there is any machine registered
        int _id;
        char selector;
		
        cout << "Type the machine's ID: ";
        cin >> _id;
        Machine Aux = search_machine_by_id(_id);
		Aux.view_machine();
	
		cout << "Choose an option: " << endl;
		cout << "[E] Edit machine " << endl;
		cout << "[S] Show procution line " << endl;
		cout << "[D] Delete machine " << endl;
		cout << "[R] Return to main menu" << endl;
		cin >> selector;
        selector = toupper(selector);

		if (selector=='E') { // Edit machine --> only capacity!!
			int a;
			cout << "Type the new capacity: ";
			cin >> a;
			Aux.modify_machine(0, &a);
			for (int i = 0; i < registeredMachines.size(); i ++) { // Changes the capacity in the vector as well
				if (Aux.get_identifier() == registeredMachines.at(i).get_identifier()) {
					registeredMachines.at(i) = Aux;
				}
			}
			storage_update();
			cout << endl;
			cout << endl;
			start_machine_register();
            }

            else {
				// Show procution line
                if (selector=='S') {
                    Aux.view_production_line();
                    cout << endl;
                    cout << endl;
                    start_machine_register();
                }

                else {
                	// Delete machine
                    if (selector=='D') {
                        delete_machine(_id);
                        storage_update();
                        cout << endl;
                        cout << endl;
                        start_machine_register();
                    }

                    else { //Return to main menu
                        cout << "Machine register says goodbye" << endl;
                        storage_update();
                    }
                }
            }
        }
		
    else { // If there isnt any machine registered
        cout << "There are no machines yet registrered" << endl;
        cout << endl;
		cout << endl;
        start_machine_register();
    }
}


/******************** search_machine_by_id **************************
*************************************************************
Operation: Searches the machine by its id and returns its obsject
Input: int identifier of the machine searched
Output: machine searched  */
Machine Facade_Machine::search_machine_by_id(int _id) {
    int i = 0; // iterator
    bool found = false;
    while (!found && i < registeredMachines.size()) {
        //cout << registeredMachines.at(i).get_identifier() << endl; ------testing---------
        found = _id == (registeredMachines.at(i)).get_identifier(); // Verifies if the machine was found
        i++;
    }
    if (found) {
        return registeredMachines.at(i-1); // i-1 beacause i++ happens even after the machine is found
    }
    else{
		int _idd;
        cout << "Machine not found, try again with a new ID" << endl;
        cin >> _idd;
		
        cout << endl;
        cout << endl;

        return search_machine_by_id(_idd);
    }
}


/******************** storage_update **************************
*************************************************************
Operation: Gets the informations registered by the user and transfer it to a file
Input: no input
Output: no output  */
void Facade_Machine::storage_update() {
    ofstream armazena("machines.csv",ios::out );
    for (int i=0; i<registeredMachines.size(); i++) {
            armazena << registeredMachines.at(i).get_identifier() << "," << registeredMachines.at(i).get_capacity() << "\n";
    }
    armazena.close();
}


/******************** delete_machine **************************
*************************************************************
Operation: removes the machine from the registres
Input: int deleted machine id
Output: no outputs  */
void Facade_Machine::delete_machine(int id) {
    int pos = returns_index(id);
	
    if (pos == registeredMachines.size()-1) {// If the machine is at the end of the vector, uses pop.back to avoid errors
        registeredMachines.pop_back();
    }
    else {
        registeredMachines.erase(registeredMachines.begin()+(pos)); // Doesnt leave empty spaces in the vector
    }
	
    cout << "Machine (id: " << id << ") deleted" << endl;
}


/******************** returns_index **************************
*************************************************************
Operation: Searches for the position where the machine is stored by its id
Input: int identifier of the machine searched
Output: int index  */
int Facade_Machine::returns_index(int _id) {
    int i = 0;
    while (_id != (registeredMachines.at(i)).get_identifier()) {
        i++;
    }
    return i;
}


/******************** update_production_line **************************
*************************************************************
Operation: Operation made so the otimazer can update the production line
Input: int idetification of the machine, int vector with the new production line
Output: no output  */
void Facade_Machine::update_production_line(int id, int *v) {
    search_machine_by_id(id).modify_machine(1,v);
}


/******************** vector_from_storage **************************
*************************************************************
Operation: Gets the information from the file so the user can see or edit it
Input: no input
Output: no output  */
void Facade_Machine::vector_from_storage() {
    ifstream file("machines.csv");
    vector<int> temporary;

    if (file.is_open()) {
        string linha;
        while (getline(file, linha)) {
    istringstream ss(linha);
    string valor1, valor2;
    getline(ss, valor1, ',');
    getline(ss, valor2, ',');
    
    int num1 = stoi(valor1);
    int num2 = stoi(valor2);

    temporary.push_back(num1);
    temporary.push_back(num2);
        
}

        file.close();
    } else {
        cout << "The file coudlnt be opened." << endl;
        
    }
/*
	--------------testing------------------
 	for (int i = 0; i < temporary.size(); i++) {
        cout << temporary[i] << endl;
    }
*/
    for (int i = 0; i < temporary.size(); i=i+2) {
        Machine Aux(temporary[i],temporary[i+1]);
        registeredMachines.push_back(Aux);
    }
}