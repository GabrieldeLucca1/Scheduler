#include "MachineManager.h"
#include "../Initializations/machine_init.h"

/******************** machine_constuctor_test **************************
*************************************************************
Operation: Perform test of class constructor method
Input: No input
Output: No output */
void machine_constuctor_test() {
    int v[5] = {1,2,3,4,5};
    Machine test_0(123,10,v);
}
/******************** get_production_line_test **************************
*************************************************************
Operation: Performs test of the function that returns pointer to the given production line. 
A random vector is supplied to the constructor of an auxiliary machine. 
Input: No input
Output: No output */
void get_production_line_test() {
    int t[5] = {1,2,3,4,5};
    Machine test_1(123,10,t);
    cout << test_1.get_production_line() << endl;
}
/******************** view_production_line_test **************************
*************************************************************
Operation: The test allows visualization of the elements provided in vector, which it has
 the production line of the created machine
Input: No input
Output: No output */
void view_production_line_test() {
    int e[5] = {1,2,3,4,5};
    Machine test_2(123,10,e);
    test_2.view_production_line();

}

/******************** modify_machine_test **************************
*************************************************************
Operation: Allows analyzing possible changes in vector information (capacity and production
line) depending on the value of the selector offered as a parameter. 0 - it changes capacity, 
1 - it changes the production line
Input: No input
Output: No output */
void modify_machine_test() {
    int w[5] = {1,2,3,4,5};
    int a = 8;
    Machine test_3(123,10,w);
    test_3.modify_machine(0,&a);
    cout << test_3.get_capacity() << endl;
    int p[5] = {1,2,7,8,9};
    test_3.modify_machine(1,p);
    test_3.view_production_line();
}

/******************** view_machine_test **************************
*************************************************************
Operation: It allows  to observe the information associated to the machine supplied
Input: No input
Output: No output */
void view_machine_test() {
    int x[5] = {9,2,3,4,5};
    Machine test_4(123,10,x);
    test_4.view_machine();
}
/******************** start_machine_register_test **************************
*************************************************************
Operation: This function will test the operation of the final machine registration service,
as well as allow changes in registration information. An auxiliary object is created for 
the facade, which is used to test the method
Input: No input
Output: No output */
void start_machine_register_test() {
    Facade_Machine Aux;
    Aux.start_machine_register();
}


/******************** test_update_text **************************
*************************************************************
Operation: An auxiliary object is created for the facade, which is used to test the method.
This method must be able to update machines data in created csv file.
Input: No input
Output: No output */

void test_update_text() {
    Facade_Machine Aux;
    Aux.storage_update();

}

/******************** vector_from_text_test **************************
*************************************************************
Operation: An auxiliary object is created for the facade, which is used to test the method.
This method must be able to take the data from the csv file and update it in the program's machines vector
Input: No input
Output: No output */

void vector_from_text_test() {
    Facade_Machine Aux;
    Aux.vector_from_storage();
   
}

// int main() {

//     // machine_constuctor_test();
//     // get_production_line_test();
//     // view_production_line_test();
//     // modify_machine_test();
//     // view_machine_test();k
//     // stores_machine_test();
//     // update_machine_test();
//     start_machine_register_test();
//     // vector_from_text_test();


//     return 0;
// }
