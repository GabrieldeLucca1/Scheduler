//#include 
#include "MajorSoftware.h"

int main(){
    MajorSoftware start;

    return 0;
}