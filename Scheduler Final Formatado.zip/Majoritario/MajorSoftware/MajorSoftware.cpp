#include "MajorSoftware.h"
#include <stdio.h>
#include <iostream>
#include <string.h>
#include "stdlib.h"
#include "../Initializations/demand_init.h"
#include "../Initializations/machine_init.h"
#include "../Initializations/products_init.h"
#include "../Initializations/optimization_init.h"

using namespace std;


MajorSoftware::MajorSoftware(){
  
   
    this->Interface();
    //Chama a interface
}
void MajorSoftware::Interface(){
    //Gera a interface
    cout<<"=======================SCHEDULER======================= "<<endl;

    cout<<"Select one service to access:"<<endl;

    cout<<"[P] Product"<<endl<<"[M] Machine"
    <<endl<<"[D] Demand"<<endl<<"[O] Optimize"<<endl<<"[V] Visualize"<<endl<<"[Q] Quit application"<<endl;

    char opcao;
    cin >> opcao;
    opcao = toupper(opcao);

            if (opcao == 'P')
                this->redirectProduto();
            else if (opcao == 'M')
                this->redirectMaquina();
            else if (opcao == 'D')
                this->redirectDemanda();
            else if (opcao == 'O')
                this->redirectOtimizar();
            else if (opcao == 'V')
                this->redirectVisualizar();
            else if (opcao == 'Q') {
                cout << "Do you want to leave scheduler? [Y] Yes / [N] No" << endl;
                char aux;
                cin >> aux;
                aux = toupper(aux);

                if(aux == 'N')
                    this->Interface();
                else
                  cout << "Application finished. Thanks for using scheduler today!" << endl;
                  exit(1);
            }
        }
MajorSoftware::~MajorSoftware(){

}
void MajorSoftware::redirectProduto(){//Chama Produto

    startProducts();
   
    MajorSoftware::Interface();
    
}
void MajorSoftware::redirectMaquina(){//Chama Maquina
    start_machine_register_test();
 
    MajorSoftware::Interface();
}
void MajorSoftware::redirectDemanda(){//Chama Demanda
    startDemands();
    MajorSoftware::Interface();

}
void MajorSoftware::redirectOtimizar(){//Chama Otimização
    startOptimization();//a receber string como parametro, nome do arquivo gerado por Demanda em Demanda::get_FileName()
   
    MajorSoftware::Interface();
}
void MajorSoftware::redirectVisualizar(){//Chama Visualização
    
    Visualizar::fakeVisualizar();//a receber string como parametro, nome do arquivo gerado por Otimizar
    
    MajorSoftware::Interface();
}