#ifndef MAJORSOFTWARE_H
#define MAJORSOFTWARE_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

class MajorSoftware{
    private:
    bool liberado;
    public:
    MajorSoftware();
    ~MajorSoftware();
    void redirectProduto();
    void redirectMaquina();
    void redirectDemanda();
    void redirectOtimizar();
    void redirectVisualizar();
    void Interface();

};

class Visualizar{
    public:
    int static fakeVisualizar(){
        cout<<"Serviço de visualização acessado."<<endl;
        cout<<"Aqui está seu Gráfico de Gantt"<<endl;
        return 1;
    }
};
#endif