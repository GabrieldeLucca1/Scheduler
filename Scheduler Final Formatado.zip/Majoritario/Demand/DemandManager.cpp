#include "DemandManager.h"
#include <sstream>
using namespace std;

DemandManager::DemandManager() { restore_file(); }

DemandManager::~DemandManager() {}

/* ******************** open_product_file *************************
*************************************************************
Operation: opens product file and saves the possible ids converting it into a
vector; Input Parameters : .csv file; Output: ids vector;
*/
vector<int> DemandManager::open_product_file(const string filename)
{

  // file reading
  ifstream input(filename);

  if (!input.is_open())
  {
    printf("\nInexistent product file!!\n");
    exit(EXIT_FAILURE);
  }
  else
  {
    vector<int> productIds;

    // read until the file is over
    while (input.good())
    {
      int idProduct, machineAmount;
      string productName;

      // reads product id and amount of machines it uses
      input >> productName;
      input >> idProduct;
      productIds.push_back(idProduct);
      input >> machineAmount;

      // reads the machines and its times
      for (int j = 0; j < machineAmount; j++)
      {
        int machine;
        int time;
        input >> machine;
        input >> time;
      }
    }

    input.close();
    return productIds;
  }
}

/* ******************** restore_file *************************
*************************************************************
Operation: saves all the information about the demands from the file as
elementos of a vector; Input Parameters : -; Output: -;
*/
void DemandManager::restore_file()
{

  // file reading
  ifstream file("demands.csv");

  if (file.is_open())
  {
    string dateStart, timeStart, dateEnd, timeEnd;
    bool finished;
    int id, day, month, year, hour, minute, amount, products, quantities;
    string line;
    // read until the file is over
    while (getline(file, line))
    {
      stringstream file(line);
      vector<int> quantity, product;
      // reads product id and amount of machines it uses
      file >> id;
      file >> dateStart;
      file >> timeStart;

      file >> dateEnd;
      file >> timeEnd;

      file >> amount;

      // reads the products and its amounts
      for (int j = 0; j < amount; j++)
      {
        file >> products;
        product.push_back(products);
        file >> quantities;
        quantity.push_back(quantities);
      }
      file >> finished;
      demands.push_back(new Demand(dateStart, timeStart, dateEnd, timeEnd, amount, quantity, product, id, finished));
    }
    file.close();
  }
}

vector<Demand *> DemandManager::get_demands() { return demands; }

/* ******************** return_written *************************
*************************************************************
Operation: returns the date and time as a string in the format "DD/MM/YYYY
HH:MM"; Input Parameters : -; Output: string with formatted date and time;
*/
string DemandManager::return_written(string date, string time)
{
  string printDay = "";

  int day = stoi(date.substr(0, 2));

  int month = stoi(date.substr(3, 2));

  int year = stoi(date.substr(6, 4));

  int hour = stoi(time.substr(0, 2));

  int minute = stoi(time.substr(3, 2));

  if (day < 10)
    printDay = '0';
  printDay += to_string(day);
  string retorno = printDay;

  string printMonth = "";
  if (month < 10)
    printMonth = '0';
  printMonth += to_string(month);

  retorno += '/' + printMonth + '/' + to_string(year);

  string printHour = "";
  if (hour < 10)
    printHour = '0';
  printHour += to_string(hour);

  string printMinute = "";
  if (minute < 10)
    printMinute = '0';
  printMinute += to_string(minute);

  retorno += " " + printHour + ':' + printMinute;
  return retorno;
}

/* ******************** record_file *************************
*************************************************************
Operation: saves the data from the vector in the file everytime there's an
update; Input Parameters : -; Output: -;
*/

void DemandManager::record_file()
{
  ofstream fout("demands.csv");

  if (!fout.is_open())
  {
    cout << "Could not open the demand file while recording." << endl;
    return;
  }

  for (const auto &demand : demands)
  {
    fout << demand->get_identifier() << " ";
    fout << demand->get_dateStart() << " " << demand->get_timeStart() << " "
         << demand->get_dateEnd() << " " << demand->get_timeEnd() << " ";
    fout << demand->get_amount() << " ";

    const auto &quantities = demand->get_productsQuantities();
    const auto &productIDs = demand->get_productsID();
    for (size_t j = 0; j < demand->get_amount(); j++)
    {
      fout << productIDs[j] << " " << quantities[j] << " ";
    }

    fout << (demand->get_isFinished() ? "1" : "0") << "\n";
  }

  fout.close();
}

/* ******************** validate_date *************************
*************************************************************
Operation: checks if a string contains a valida data in the format DD/MM/YYYY;
Input Parameters : string data;
Output: true if is valid, false if not;
*/

bool DemandManager::validate_date(string date)
{
  int day, month, year;

  if (date.size() !=
      10)
  { // date should be in the format DD/MM/YYYY => size should be 10
    return false;
  }

  day = stoi(date.substr(0, 2));
  if (day > 31 || day < 1)
  { // checking if it's a number
    return false;
  }

  month = stoi(date.substr(3, 2));

  if (month > 12 || month < 1)
  { // checking if it's a number
    return false;
  }

  year = stoi(date.substr(6, 4));
  if (year < 2023)
  { // checking if it's a number
    return false;
  }

  return true;
}

/* ******************** validate_time *************************
*************************************************************
Operation: checks if a string contains a valida time in the format HH:MM;
Input Parameters : string horario;
Output: true if is valid, false if not;
*/
bool DemandManager::validate_time(string time)
{
  int hour, minute;

  if (time.size() !=
      5)
  { // date should be in the format DD/MM/YYYY => size should be 10
    return false;
  }

  hour = stoi(time.substr(0, 2));

  if (hour > 23 || hour < 0)
  {
    return false;
  }

  minute = stoi(time.substr(3, 2));

  if (minute > 59 || minute < 0)
  {
    return false;
  }

  return true;
}

/* ******************** print_demand *************************
*************************************************************
Operation: prints all the data from a demand;
Input Parameters : int posicao, the position of the demand in the vector;
Output: -;
*/

void DemandManager::print_demand(int position)
{
  for (int i = 0; i < demands.at(position)->get_amount();
       i++)
  {
    cout << "Product " << demands.at(position)->get_productsID().at(i) << ": "
         << (demands.at(position)->get_productsQuantities()).at(i) << endl;
  }
  cout << "Status: ";
  if (demands.at(position)->get_isFinished())
  {
    cout << "Finished" << endl;
  }
  else
  {
    cout << "On progress" << endl;
  }
}

/* ******************** return_position *************************
*************************************************************
Operation: finds the position of a object in the vector based on its id;
Input Parameters : int id;
Output: int with the position, -1 if the demand is not on the system;
*/

int DemandManager::return_position(int identifier)
{

  for (int i = 0; i < demands.size(); i++)
  {
    int aux = (demands.at(i))->get_identifier();
    if (aux == identifier)
    { // if the demand in the position 'i' has and id ==
      // of the given one, return i
      return i;
    }
  }
  return -1;
}

/* ******************** register_demand *************************
*************************************************************
Operation: registers a new demand;
Input Parameters : Demand demand;
Output:-;
*/
void DemandManager::register_demand(vector<int> productsID)
{
  int identifier;
  string newDateStart, newTimeStart, newDateEnd, newTimeEnd;
  vector<int> productsQuantities, productIDs;
  bool validId = false;

  while (validId == false)
  {
    cout << "Type the identifier." << endl;
    cin >> identifier;
    if (return_position(identifier) != -1)
    {
      cout << "Demand already registered. Informations about it: " << endl
           << endl;
      print_demand(return_position(identifier));
      cout << endl
           << "Try again with a valid ID" << endl;
      validId = false;
    }
    else
    {
      validId = true;
      bool valid = false;
      while (valid == false)
      {
        cout << "Insert start date in the following format DD/MM/YYYY:" << endl;
        cin >> newDateStart;
        if (!validate_date(newDateStart))
          cout << "Invalid date" << endl;
        else
          valid = true;
      }

      valid = false;
      while (valid == false)
      {
        cout << "Insert start time in the following format HH:MM." << endl;
        cin >> newTimeStart;
        if (!validate_time(newTimeStart))
        { // verifica se o horário é válido
          cout << "Invalid time" << endl;
        }
        else
        {
          valid = true;
        }
      }

      valid = false;
      while (valid == false)
      {
        cout << "Insert end date in the following format DD/MM/YYYY." << endl;
        cin >> newDateEnd;
        if (!validate_date(newDateEnd))
        {
          cout << "Invalid date" << endl;
        }
        else
        {
          valid = true;
        }
      }

      valid = false;
      while (valid == false)
      {
        cout << "Insert end time in the following format HH:MM." << endl;
        cin >> newTimeEnd;
        if (!validate_time(newTimeEnd))
        { // verifica se o horário é válido
          cout << "Invalid time" << endl;
        }
        else
        {
          valid = true;
        }
      }

      cout << "How many different products does this demand have?" << endl;
      int howManyProducts, productIdentifier, productQuantity;
      cin >> howManyProducts;
      for (int i = 0; i < howManyProducts; i++)
      {
        bool exists = false;
        while (exists == false)
        {
          cout << "Insert the code of product " << (i + 1) << endl;
          cin >> productIdentifier;

          // checking if there is a product with the given id registered
          for (int v = 0; v < productsID.size(); v++)
          {
            if (productIdentifier == productsID[v])
              exists = true;
          }
          if (exists == false)
            cout << "The product is not registered in the system, please "
                    "insert a valid product ID"
                 << endl;
        }

        productIDs.push_back(productIdentifier);
        cout << "Insert the amount of product " << productIdentifier
             << endl;
        cin >> productQuantity;
        productsQuantities.push_back(productQuantity);
      }
      demands.push_back(new Demand(
          newDateStart, newTimeStart, newDateEnd, newTimeEnd, howManyProducts,
          productsQuantities, productIDs, identifier,
          false)); // sends the demand to be saved in the vector and in the file
      record_file();
      cout << "Successfully registered!" << endl;
    }
  }
}

/* ******************** update_products *************************
*************************************************************
Operation: updates the quantities of products of a demand;
Input Parameters : int posicao;
Output: -;
*/
void DemandManager::update_products(int position)
{

  vector<int> newQuantities, newProducts;
  cout << "How many products does this demand have?" << endl;
  int howManyProducts;
  cin >> howManyProducts;

  if (howManyProducts < 1)
    cout << "Invalid amount";

  else
  {
    for (int i = 0; i < howManyProducts; i++)
    {
      int product_id, product_quantity;
      cout << "Insert the ID of product number " << i + 1 << endl;
      cin >> product_id;
      newProducts.push_back(product_id);

      cout << "Insert the amount of product with ID " << product_id << endl;
      cin >> product_quantity;
      newQuantities.push_back(product_quantity);
    }

    // creates a new demand
    demands.at(position) = new Demand(
        demands.at(position)->get_dateStart(),
        demands.at(position)->get_timeStart(),
        demands.at(position)->get_dateEnd(),
        demands.at(position)->get_timeEnd(), howManyProducts, newQuantities,
        newProducts, demands.at(position)->get_identifier(),
        demands.at(position)->get_isFinished());

    cout << "Successfully changed" << endl;
  }
}

/* ******************** update_DateTime *************************
*************************************************************
Operation: updates the start date and time of a demand;
Input Parameters : int posicao;
Output: -;
*/
void DemandManager::update_DateTime(int position, bool start)
{

  string newDate, newTime;
  cout << "Insert the new date in the following format DD/MM/YYYY." << endl;
  cin >> newDate;
  if (!validate_date(newDate))
  { // checks if the date is valid
    cout << "Invalid date" << endl;
  }

  else
  {
    cout << "Insert the new time in the following format HH:MM." << endl;
    cin >> newTime;
    if (!validate_time(newTime))
    { // checks if the date is valid
      cout << "Invalid time";
    }

    else
    {
      if (start == true)
      {
        demands.at(position) =
            new Demand(newDate, newTime, demands.at(position)->get_dateEnd(),
                      demands.at(position)->get_timeEnd(),
                       demands.at(position)->get_amount(),
                       demands.at(position)->get_productsQuantities(),
                       demands.at(position)->get_productsID(),
                       demands.at(position)->get_identifier(),
                       demands.at(position)->get_isFinished());
      }
      else
      {
        demands.at(position) =
            new Demand(demands.at(position)->get_dateStart(),
                       demands.at(position)->get_timeStart(), newDate, newTime,
                       demands.at(position)->get_amount(),
                       demands.at(position)->get_productsQuantities(),
                       demands.at(position)->get_productsID(),
                       demands.at(position)->get_identifier(),
                       demands.at(position)->get_isFinished());
      }
    }
  }
}

/* ******************** update *************************
*************************************************************
Operation: show all possibilities of update, finds the position of the object
and directs the program to the right update method; Input Parameters : -;
Output: -;
*/
void DemandManager::update()
{

  int identifier;
  cout << "Insert the demand identifier: " << endl;
  cin >> identifier;

  bool aux = false;
  while (aux == false)
  {
    if (return_position(identifier) == -1)
    {
      cout << "Demand not registered, try again with a "
              "valid one"
           << endl;
      aux = true;
    }
    else
    {
      print_demand(
          return_position(identifier)); // shows the demand they want to update
      cout << "Edition options" << endl;
      cout << "[S] Start date " << endl;
      cout << "[E] End date" << endl;
      cout << "[A] Amount and product" << endl;
      cout << "[D] Delete" << endl;
      cout << "[Q] Quit edition mode" << endl;
      cout << "> ";

      char option;
      cin >> option;
      option = toupper(option);

      int position = return_position(identifier);
      switch (option)
      {
      case 'S':
        update_DateTime(position, true);
        record_file();
        break;
      case 'E':
        update_DateTime(position, false);
        record_file();
        break;
      case 'A':
        update_products(position);
        record_file();
        break;
      case 'D':
        demands.erase(demands.begin() + (return_position(identifier)));
        record_file();
        cout << "Sucessfully deleted" << endl;
        break;
      case 'Q':
        cout << "Returning to the menu" << endl;
        aux = true;
        break;
      }
    }
  }
}