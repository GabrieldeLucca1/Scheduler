#include "Demand.h"
#include <iostream>
#include <locale>
#include <fstream>
#include <string>

using namespace std;

class DemandManager
{
private:
	vector <Demand*> demands;

	//method to update the products and its quantities
	void update_products(int position);

	//method to update date and time
	void update_DateTime(int position, bool start);

	//method to save a given Demand
	void record_file();

	//method to get the data from the file
	void restore_file();

public:
	DemandManager();
	~DemandManager();

  //method to open product file and convert it into vector of ids
  vector<int> open_product_file(const string);

	//method to print the information of a specific demand
	void print_demand(int position);

	//method that finds the position of a specific demand in the vector
	int return_position(int identifier);

	//method that checks if a string is a valid date in the format DD/MM/YYYY
	bool validate_date(string date);

	//method that checks if a string is a valid time in the format HH:MM
	bool validate_time(string time);

	//method to add a demand to the vector
	void register_demand(vector <int>);

	vector<Demand*> get_demands();

	//method to update a demand
	void update();

  string return_written(string date, string time);
};
