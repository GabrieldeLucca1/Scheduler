#include "Demand.h"

Demand::Demand(string dateStart, string timeStart, string dateEnd, string timeEnd, int amount, vector<int> productsQuantities, vector<int> productsID, int identifier, bool finished) :
	dateStart(dateStart), timeStart(timeStart), dateEnd(dateEnd), timeEnd(timeEnd), amount(amount), productsQuantities(productsQuantities), productsID(productsID),identifier(identifier), isFinished(finished)
{

}

Demand::~Demand() {
}

vector<int> Demand::get_productsID() {
	return productsID;
}

/* ******************** update *************************
*************************************************************
Operation: Update all the attributs of the demand, except identifier e isFinished;
Input Parameters : Demand updatedDemand;
Output: -;
*/
void Demand::update(Demand& updatedDemand) { //updates this demand based on the updatedDemand
	//id and isFinished cannot be updated through this method
	set_dateStart(updatedDemand.get_dateStart());
  set_timeStart(updatedDemand.get_timeStart());
	set_dateEnd(updatedDemand.get_dateEnd());
  set_timeEnd(updatedDemand.get_timeEnd());
set_productsQuantities(updatedDemand.get_productsQuantities());
	set_productsID(updatedDemand.get_productsID());
}

string Demand::get_dateStart() {
	return dateStart;
}

string Demand::get_timeStart() {
	return timeStart;
}

string Demand::get_dateEnd() {
	return dateEnd;
}

string Demand::get_timeEnd() {
	return timeEnd;
}

bool Demand::get_isFinished() {
	return isFinished;
}

vector<int> Demand::get_productsQuantities() {
	return productsQuantities;
}

int Demand::get_identifier() {
	return identifier;
}

int Demand::get_amount() {
	return amount;
}

void Demand::set_dateStart(string newDate) {
	dateStart = newDate;
}

void Demand::set_timeStart(string newTime) {
	timeStart = newTime;
}

void Demand::set_dateEnd(string newDate) {
	dateEnd = newDate;
}

void Demand::set_timeEnd(string newTime) {
	timeEnd = newTime;
}

void Demand::set_isFinished(bool newState) {
	isFinished = newState;
}

void Demand::set_productsQuantities(vector<int> newQuantities) {
	productsQuantities.clear();
	for (int i = 0; i < productsQuantities.size(); i++) {
		productsQuantities.push_back(newQuantities.at(i));
	}
}

void Demand::set_productsID(vector<int> newProducts) {
	productsID.clear();
	for (int i = 0; i < productsID.size();i++) {
		productsID.push_back(newProducts.at(i));
	}
}

/* ******************** finishDemand * *************************
*************************************************************
Operation: Alters the state of the Demand to finished setting the attribute isFinished to true;
Input Parameters : -;
Output: -;
*/

void Demand::finishDemand() {
	set_isFinished(true);
}
