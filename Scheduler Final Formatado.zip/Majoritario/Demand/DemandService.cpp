#include "DemandManager.h"
#include "../Initializations/demand_init.h"

using namespace std;

void startDemands() {

  setlocale(LC_ALL, "portuguese");
  DemandManager manager;
  vector<int> productID;

  while (true) {
    cout << "=======================Demands======================= " << endl;
    cout << "[R] Register a new demand" << endl;
    cout << "[E] Edit an existing demand" << endl;
    cout << "[Q] Quit service" << endl;

    char opcao;
    cin >> opcao;
    opcao = toupper(opcao);

    if (opcao == 'R') {
      productID = manager.open_product_file("products.csv");
      manager.register_demand(productID);
    } else if (opcao == 'E') {
      manager.update();
    } else if (opcao == 'Q') {
      cout << "Thanks for using our service today!" << endl;
      return ;
    } else
      cout << "Inser a valid option";
  }
}

