#include <iostream>
#include <vector>

using namespace std;
class Demand
{
private:
	string dateStart, dateEnd, timeStart, timeEnd;
	vector<int> productsQuantities;
	bool isFinished;
	vector<int> productsID;
	int identifier, amount;

	void set_dateEnd(string newDate);
	void set_dateStart(string newDate);
	void set_timeEnd(string newTime);
	void set_timeStart(string newTime);
	void set_isFinished(bool newState);
	void set_productsID(vector<int> newProducts);
	void set_productsQuantities(vector<int> productsQuantities);

public:
	Demand(string dateStart, string timeStart, string dateEnd, string timeEnd, int amount, vector<int> productsQuantities, vector<int> productsID,  int identifier, bool finished);
	~Demand();

	void update(Demand& updatedDemand);
	string get_dateStart();
	string get_dateEnd();
	string get_timeStart();
	string get_timeEnd();
	bool get_isFinished();
  	int get_amount();
	vector<int> get_productsQuantities();
	int get_identifier();
	vector<int> get_productsID();

	//changes state of the demand to finished
	void finishDemand();

};
