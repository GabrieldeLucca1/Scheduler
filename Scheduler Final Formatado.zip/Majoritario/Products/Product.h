#ifndef PRODUCT_H
#define PRODUCT_H
#include <string> // Library for string manipulation
using namespace std;
#include <vector> // Library for vector manipulation
#include <iostream>

class Product{
  public:
    Product(string productName, int productId,  vector<int> &_machineId, vector<double> &_manufacturingTime, int numberMachines);
    ~Product();
    string get_product_name()const;
    void set_product_name(string productName);
    int get_product_id()const;
    void set_product_id(int productId);
    vector<int> get_machine_id()const;
    void set_machine_id(const vector<int> &_machineId);
    vector<double> get_manufacturing_time()const;
    void set_manufacturing_time(const vector<double> &_manufacturingTime);
    void print_a_product();
    int get_amout_machines();
    void set_number_machines(int numberMachines);
  
  private:
    int numberMachines;
    string productName;
    int productId; // Product unique identifier
    vector<int> machineId; // Contains all the identifiers of the machines that manufacture that specific product
    vector<double> manufacturingTime; // Contains each machine's manufacturing time for that specific product
    vector<Product *> products;
};

#endif