#include "Product.h"
#include <string.h>

Product::Product(string productName, int productId, vector<int>& _machineId, vector<double>& _manufacturingTime, int numberMachines):productName(productName),productId(productId),machineId(_machineId),manufacturingTime(_manufacturingTime), numberMachines(numberMachines){
     
}

Product::~Product(){
    
}

int Product::get_amout_machines()  {

  return numberMachines;
}

string  Product::get_product_name()const{
  int i = 0;
  string product = this->productName;
  while(product[i] != '\0'){
    if(product[i] == ' ')
      product[i] = '_';
    i++;
  }
  return product;  
}


void  Product::set_product_name(string productName){
  this->productName = productName;  
}

int Product:: get_product_id()const{
  return productId;  
}

void Product:: set_product_id(int productId){
  this->productId = productId;  
}

vector<int> Product:: get_machine_id()const{
  return machineId;  
}

void Product:: set_machine_id(const vector<int> &machineId) {
  this->machineId = machineId;
}

vector<double>  Product::get_manufacturing_time()const{
  return manufacturingTime;  
}

void Product::set_number_machines(int numberMachines){
  this->numberMachines = numberMachines;
}

void Product:: set_manufacturing_time(const vector<double>& manufacturingTime){
  this-> manufacturingTime = manufacturingTime;  
}

void Product::print_a_product(){
  cout<< "Product's name: "<<productName<<endl;
  cout<< "Product ID: "<<productId<<endl;
  for(int j = 0;j<machineId.size();j++){
    cout<< "Allocated machine: "<<machineId[j]<<endl;  
    cout<< "Manufacturing time: "<<manufacturingTime[j]<<endl;
  }    
}