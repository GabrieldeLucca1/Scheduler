#include "Product.h"
#include "ProductManager.h"
#include "../Initializations/products_init.h"
using namespace std;

// Função que realiza a lógica do programa de produtos
void startProducts() {
  char op;
  int id;

  ProductManager ProductManagers("machines.csv","products.csv");

  do {
    cout<< "=======================Products======================= "<<endl;
    op = ProductManager::ui_options();
    switch (op) {
      case 'P': { 
        ProductManagers.print_all_products();
        break;
      }
      case 'C': {
        cout << "Product ID: ";
        cin >> id;
        ProductManagers.print_specific_product(id);
        break;
      }
      case 'R': {
        ProductManagers.register_product();
        break;
      }
      case 'N': {
        cout << "Product ID: ";
        cin >> id;
        bool ok = ProductManagers.update_product_name(id);
        cout << "Name update " << (ok ? "was done successfully" : "error: Invalid ID") << endl;
        break;
      }
      case 'I': {
        cout << "Product ID: ";
        cin >> id;
        bool ok = ProductManagers.update_product_id(id);
        cout << "Product ID Update " << (ok ? "was done successfully" : "error: Invalid ID") << endl;
        break;
      }
      case 'M': {
        cout << "Product ID: ";
        cin >> id;
        bool ok = ProductManagers.update_machines_spec(id);
        cout << "Product's machine specifications update " << (ok ? "was done successfully" : "error: Invalid ID") << endl;
        break;
      }
      case 'D': {
        cout << "Product ID: ";
        cin >> id;
        bool ok = ProductManagers.remove_product(id);
        cout << "Product deletion " << (ok ? "was done successfully" : "error: Invalid ID") << endl;
        break;
      }
    }
    cout << endl;
  } while (op != 'Q');
  cout << "Product service says goodbye" << endl;
}

// int main() {
//   
//   startProdutos();

//   return 0;
// }