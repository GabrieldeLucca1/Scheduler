#include "ProductManager.h"
#include "Product.h"
#include <fstream> // Library used for file manipulation
#include <sstream> // Library used for both files' string manipulation

ProductManager::ProductManager(string fileMachine, string fileProduct):fileMachine(fileMachine), fileProduct(fileProduct){
  read_product_csv();
  read_machine_csv();
}

ProductManager::~ProductManager(){

}

/* ******************* READ_PRODUCT_CSV **************************
*************************************************************
Operation: Read all products' data from the .csv file, with each parameter being separated by the character ',';
Input parameters: Doesn't apply;
Output: All the products' data read from the file;
Status: Complete
; */
void ProductManager::read_product_csv(){
  ifstream file(fileProduct); // Opens the .csv file in read-only mode   
  if(file.is_open()){ // Verifies if the file was opened successfully
    string line;
    while(getline(file, line)){ // Reads each of the file's lines
      stringstream ss(line); // Creates a stringstream to process each of the file's lines
      string productName;
      int productId, auxNumberMachines; // Counter that indicates how many machines can manufacture each product
      vector<int> tempMachineId; // Auxiliar vector for every machineId
      vector<double> tempManufacturingTime; // Auxiliar vector for the machine's respective manufacturing time
      
      // Gets each value separated by a ' ' and stores then in the variables
      getline(ss, productName, ' ');
      ss >> productId;
      ss.ignore(); // Ignores a ' '
      ss >> auxNumberMachines;
      
      for(int i = 0; i < auxNumberMachines; i++) {
        int machine;
        double time;
        ss.ignore();
        ss >> machine;
        ss.ignore();
        ss >> time;
        tempMachineId.push_back(machine); // Inserts a machine ID on the vector
        tempManufacturingTime.push_back(time); // Inserts a machine's manufacturing time on the vector
      }

      Product *p = new Product(productName, productId, tempMachineId, tempManufacturingTime, auxNumberMachines); // Creates a Product object that contains all the read parameters
      products.push_back(p); // Adds the new Product to the Product vector
    }
    file.close(); // Closes the file
  }
}

/* ******************* READ_MACHINE_CSV **************************
*************************************************************
Operation: Read all valid machines' data from the .csv file, with each parameter being separated by the character ',';
Input parameters: Doesn't apply;
Output: All the valid machines' data read from the file;
Status: Complete
; */
void ProductManager::read_machine_csv(){
  ifstream file(fileMachine); // Opens the .csv file in read-only mode
  if(file.is_open()){ // Verifies if the file was opened successfully
    string line;
    while(getline(file, line)){ // Reads each of the file's lines
      stringstream ss(line); // Creates a stringstream to process each of the file's lines
      int machineId;
      ss >> machineId; // Gets each value separated by a ',' and stores then in the variables    
      validMachineIds.push_back(machineId); // Inserts a valid machine ID on the vector
    }   
    file.close();
  }
}

/******************** WRITE_PRODUCT_CSV **************************
*************************************************************
Operation: Write all the registered products' data in the .csv file;
Input parameters: Doesn't apply;
Output: Written file that contains all the registered products' data;
Status: Complete
; */
void ProductManager::write_product_csv(){
  ofstream file(fileProduct); // Opens the .csv file in read-only mode
  if(file.is_open()){ // Verifies if the file was opened successfully
  int j = 0;
    while(j  < products.size()){ // Goes through the Product vector using the get functions and inserts them in the file
      Product *p = products[j];
      file << p->get_product_name() << " " << p->get_product_id() << " " << p->get_amout_machines() << " ";
      for(int i = 0; i < p->get_amout_machines(); i++) {
        file << p->get_machine_id()[i] << " " << p->get_manufacturing_time()[i];
        if(i < p->get_amout_machines() - 1) {
          file << " "; // Inserts the '' to follow the .csv file pattern
        }
      }
      j++;
      file << endl;
    }
    file.close(); // Closes the .csv file
  }
}

/******************** REGISTER_PRODUCT **************************
*************************************************************
Operation: Register a product's parameters in the Product vector and writes it in the .csv file;
Input parameters: productName, productId, machines on which the product can be manufactured and time spent in the manufacturing process;
Output: Product register in the Product vector and .csv file;
Status: Complete
; */
bool ProductManager::register_product(){
  int productId, machine, auxNumberMachines;
  string productName;
  Product * p1;
  char c;
  double time;

  tempMachineId.clear();
  tempManufacturingTime.clear();

  // Product register function's interface
  cin.ignore();
  getline(cin, productName);
  bool validId = false; // Assumes right from the start that the product ID isn't valid
  while(!validId){
    cin >> productId;
    if(!verify_product_id(productId))
      cout<<"This product ID has already been used!"<<endl; // That ID is invalid because it was used already
    else
      validId = true;
  }
  cout << "Write how many machines this product can be manufactured on:";
  cin >> auxNumberMachines;

  for(int i=0; i<auxNumberMachines; i++) {
    cout << "Write the machine's ID:";
    cin >> machine;
    if(!verify_machine_id(machine)){
      cout<<" Invalid machine ID!"<<endl;
      i--; // Stays in the same loop iteration so it can keep asking for a valid machine ID
      cout<<"These are the valid machine IDs:" << endl;
      print_machines();
    }
    else{
      tempMachineId.push_back(machine);
      cout << "Write how much time the product takes to manufacture for this machine:";
      cin >> time;
      tempManufacturingTime.push_back(time);
    }
  }

  p1 = new Product(productName, productId, tempMachineId, tempManufacturingTime, auxNumberMachines); // Constructs the new Product

  products.push_back(p1); // Inserts the new Product in the vector
  write_product_csv(); // Writes the new Product in the .csv file
  p1 = nullptr;
  return true;
}

/******************** VERIFY_PRODUCT_ID **************************
*************************************************************
Operation: Verify if the given product ID hasn't already been used in the product .csv file, i.e, if it is valid;
Input parameters: The product ID that is going to be registered;
Output: True if the product ID is valid, False otherwise;
Status: Complete
; */
bool ProductManager:: verify_product_id(int id){
  for(int i = 0; i<products.size();i++)
    if(id == products[i]->get_product_id())
      return false;
  return true;
}

/******************** VERIFY_MACHINE_ID **************************
*************************************************************
Operation: Verify if the machine ID given is registered in the valid machines .csv file, i.e, if it is valid;
Input parameters: The machine ID that is going to be registered;
Output: True if the ID is valid, False if otherwise;
Status: Complete
; */
bool ProductManager:: verify_machine_id(int id){
  for(int i = 0; i<validMachineIds.size();i++)
    if(id == validMachineIds[i])
      return true;
  return false;
}

/******************** REMOVE_PRODUCT **************************
*************************************************************
Operation: Remove a product from the .csv file;
Input parameters: The to-be removed product's ID;
Output: True if the product was removed successfully, False if otherwise;
Status: Complete
; */
bool ProductManager::remove_product(int id){
  bool ok = false;
  int index = product_index(id); // Receives the vector index that contains the Product with that specific ID
  
  if (index != -1) { // The to-be removed Product was found
    products.erase(products.begin() + index);
    write_product_csv();
    ok = true; // Product removed sucessfully
  }
  return ok;  
}

/******************** PRODUCT_INDEX **************************
*************************************************************
Operation: Returns the vector index which contains the product with that specific ID;
Input parameters: Product ID used to search in the vector;
Output: Vector index on which the product was saved;
Status: Complete
; */
int ProductManager::product_index(int id) {
  long unsigned int size = products.size();
  long unsigned int index = 0;

  while (index < size && products[index]->get_product_id() != id)
    index++;

  if (index < size)
    return index;
  else
    return -1; // Indicates that no Product with the given ID was found
}

/******************** PRODUCT_COUNTER **************************
*************************************************************
Operation: Obtain how many products are registered in the product vector;
Input parameters: Doesn't apply;
Output: Product vector's size;
Status: Complete;
; */
int ProductManager::product_counter(){
  return products.size();
}

/******************** PRINT_ALL_PRODUCTS *********************
*************************************************************
Operation: Print every registered products' data in the console screen;
Input parameters: Doesn't apply;
Output: All products' data printed in the console screen;
Status: Complete
; */
void ProductManager::print_all_products(){
  cout<< "Number of machines: "<< product_counter()<<endl;
  for (long unsigned int i = 0; i < products.size(); i++) {
    products[i]->print_a_product();
    cout << endl;
  }
}

/******************** PRINT_SPECIFIC_PRODUCT *********************
*************************************************************
Operation: Search the product vector by the product's ID and print all the information about that specific product;
Input parameters: To-be printed product's ID;
Output: That product's specifications printed in the console screen;
Status: Complete
; */
void ProductManager::print_specific_product(int id){
  int index = product_index(id); // Obtains the Product's index in the Product vector by its ID

  if (index != -1) // If a product is found
    products[index]->print_a_product(); // Prints that specific product
  else
    cout << "ID not found.";
}

/******************** PRINT_MACHINES **************************
*************************************************************
Operation: Print all the registered machine IDs;
Input parameters: Doesn't apply;
Output: All the machine IDs that are valid for registration printed in the console screen;
Status: Complete
; */
void ProductManager::print_machines(){
  for(int i = 0; i < validMachineIds.size();i++)
    cout<< "Machine ID: "<<validMachineIds[i]<<endl;
}

/******************** UPDATE_NAME **************************
*************************************************************
Operation: Update the given product's name parameter;
Input parameters: ID of the product that will have its name changed;
Output: True if the product was sucessfully update, False if otherwise;
Status: Complete
; */
bool ProductManager:: update_product_name(int id){
  string productName;
  bool ok = false;
  int index = product_index(id);

  if(index != -1) {
    cin.ignore(); // Ignores one ',' in the .csv file
    cout <<" Updated Name: ";
    getline(cin, productName);
    products[index]-> set_product_name(productName); // Updates the Product's name in the Product vector
    write_product_csv(); // Writes the updated Product in the .csv file
    ok = true;      
  }
    return ok;
}

/******************** UPDATE_PRODUCT_ID **************************
*************************************************************
Operation: Update the ID parameter of a specific product;
Input parameters: The to-be modified product's ID;
Output: True if the product was sucessfully updated, False if otherwise;
Status: Complete
; */
bool ProductManager:: update_product_id(int _id){
  int productId;
  bool ok = false;
  int index = product_index(_id);

  if(index != -1) {
    bool validId = false;
    while(!validId){
      cout << "Product ID: ";
      cin >> productId;
      if(!verify_product_id(productId))
        cout<<"This product ID has already been used!"<<endl;
      else
        validId = true;
    }
    products[index]-> set_product_id(productId); // Updates the Product's ID in the Product vector
    write_product_csv(); // Writes the updated Product in the .csv file
    ok = true;      
  }
  return ok;
}

/******************** UPDATE_MACHINES_SPEC ***********************
*************************************************************
Operation: Update the following specifications: Which machines can manufacture that product and how much time is spent for its manufacturing;
Input parameters: The ID of the product that will have its specifications be modified;
Output: True if the product was successfully updated, False if otherwise;
Status: Complete
; */
bool ProductManager:: update_machines_spec(int id){
  double time;
  int machine, auxNumberMachines;
  bool ok = false;
  int index = product_index(id); // Product's index in the Product vector

  if(index != -1) { // The Product was found in the Product vector
    tempMachineId.clear();
    tempManufacturingTime.clear();
    cout << "Write how many machines this product can be manufactured on:";
    cin >> auxNumberMachines;
    for(int i=0; i<auxNumberMachines; i++) {
      cout << "Write the machine's ID:";
      cin >> machine;
      if(!verify_machine_id(machine)){
        cout<<"Invalid Machine!"<<endl;
        cout << "Valid machines: "<<endl;
        print_machines();
        i--;
      }
      else{
        tempMachineId.push_back(machine); // Registers a new machine on which the Product can be manufactured
        cout << "Write how much time the product takes to manufacture for each machine:";
        cin >>time;
        tempManufacturingTime.push_back(time); // Registers a new manufacturing time for that product in the machine previously registered
      }
    }

    products[index]-> set_number_machines(auxNumberMachines);
    products[index]-> set_machine_id(tempMachineId); // Inserts in the Product vector all machines that can manufacture the Product
    products[index]-> set_manufacturing_time(tempManufacturingTime); // Inserts in the Product vector the manufacturing time for each machine
    write_product_csv(); // Writes the updated product in the .csv file
    ok = true;      
  }
  return ok;
}

/******************** OPTION **************************
*************************************************************
Operation: Basic interface for the product register service
Input parameters: Keyboard key pressed for the operation of choice;
Output: Selected operation;
Status: Complete
; */
char ProductManager::ui_options() {
    char c;
    cout << "[P] Print all" << endl;
    cout << "[C] Print a specific product" << endl;
    cout << "[R] Register a product" << endl;
    cout << "[N] Update a product's name" << endl;
    cout << "[I] Update a product's ID" << endl;
    cout << "[M] Update a product's machine specifications" << endl;
    cout << "[D] Delete a product" << endl;
    cout << "[Q] Quit service" << endl;
    cout << "> ";
    cin >> c;
    return (toupper(c)); // Converts a lowercase character to a uppercase character if necessary
}