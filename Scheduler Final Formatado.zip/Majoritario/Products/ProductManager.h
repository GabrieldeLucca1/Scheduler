#ifndef PRODUCTMANAGER_H
#define PRODUCTMANAGER_H

#include "Product.h"
#include <vector>
using namespace std;

class ProductManager {
  public:
    ProductManager(string fileMachine, string fileProduct);
    virtual ~ProductManager();
    bool register_product();
    bool remove_product(int id);
    bool update_product_name(int id);
    bool update_product_id(int id);
    bool update_machines_spec(int id);
    int product_counter();
    void print_all_products();
    void print_specific_product(int id);
    bool verify_product_id (int id);
    bool verify_machine_id (int id);
    void print_machines();
    static char ui_options();
  private:
    void write_product_csv();
    void read_product_csv();
    void read_machine_csv();
    int product_index (int id);
    string fileMachine; // Name of the file that contains the valid machine IDs
    string fileProduct; // Name of the output file that contains all registered products
    vector<Product *> products;
    vector<int> validMachineIds; // Vector that has all the valid machine IDs 
    vector<int> tempMachineId; // Auxiliar vector for all machine IDs
    vector<double> tempManufacturingTime; // Auxiliar vector for all machine's manufacturing times

};

#endif /* ProductManager_H */